import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/auth_user.dart';
import 'api_client.dart';
import 'api_exception.dart';

/// Signing in, signing out, and remembering who is signed in.
///
/// The token and the teacher's details are kept in SharedPreferences only
/// when "Keep me signed in" is ticked, so a shared computer does not stay
/// signed in after the teacher closes the app.
class AuthService extends ChangeNotifier {
  AuthService({ApiClient? client}) : _api = client ?? ApiClient();

  static final AuthService instance = AuthService();

  static const _tokenKey = 'auth_token';
  static const _userKey = 'auth_user';
  static const _expiryKey = 'auth_expires_at';

  final ApiClient _api;

  AuthUser? _user;
  String? _token;
  DateTime? _expiresAt;

  AuthUser? get currentUser => _user;
  String? get token => _token;
  bool get isSignedIn => _token != null && _user != null && !_isExpired;

  bool get _isExpired =>
      _expiresAt != null && DateTime.now().isAfter(_expiresAt!);

  /// The API client other services can reuse, already carrying the token.
  ApiClient get api => _api;

  /// Reads a saved session at start-up. Returns true when the app can go
  /// straight to the dashboard.
  Future<bool> restoreSession() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString(_tokenKey);
      final userJson = prefs.getString(_userKey);
      final expiry = prefs.getString(_expiryKey);
      if (token == null || userJson == null) return false;

      _token = token;
      _api.authToken = token;
      _user = AuthUser.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
      _expiresAt = expiry == null ? null : DateTime.tryParse(expiry);

      if (_isExpired) {
        await signOut();
        return false;
      }

      // Confirm with the server that the token is still accepted: the account
      // may have been deactivated since the last sign-in.
      try {
        final me = await _api.get('auth/me');
        _user = AuthUser.fromJson(me);
        notifyListeners();
        return true;
      } on ApiException catch (e) {
        if (e.isUnauthorized) {
          await signOut();
          return false;
        }
        // A server-side problem is not the teacher's fault; keep the saved
        // session and let them work, rather than forcing a sign-in.
        return true;
      } on NetworkException {
        // Offline at start-up. Trust the saved session for now.
        return true;
      }
    } catch (_) {
      return false;
    }
  }

  /// Throws [ApiException] when the credentials are refused and
  /// [NetworkException] when the API cannot be reached.
  Future<AuthUser> signIn({
    required String email,
    required String password,
    bool rememberMe = false,
  }) async {
    final body = await _api.post('auth/login', {
      'email': email.trim(),
      'password': password,
    });

    final token = body['token'] as String?;
    final teacher = body['teacher'];
    if (token == null || teacher is! Map<String, dynamic>) {
      throw ApiException('The server sent an unexpected reply.', 500);
    }

    _token = token;
    _api.authToken = token;
    _user = AuthUser.fromJson(teacher);
    _expiresAt = DateTime.tryParse(body['expiresAt'] as String? ?? '');

    if (rememberMe) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_tokenKey, token);
      await prefs.setString(_userKey, jsonEncode(_user!.toJson()));
      if (_expiresAt != null) {
        await prefs.setString(_expiryKey, _expiresAt!.toIso8601String());
      }
    }

    notifyListeners();
    return _user!;
  }

  Future<AuthUser> register({
    required String email,
    required String password,
    required String fullName,
    String? department,
  }) async {
    final body = await _api.post('auth/register', {
      'email': email.trim(),
      'password': password,
      'fullName': fullName.trim(),
      'department': department?.trim(),
    });

    _token = body['token'] as String?;
    _api.authToken = _token;
    _user = AuthUser.fromJson(body['teacher'] as Map<String, dynamic>);
    _expiresAt = DateTime.tryParse(body['expiresAt'] as String? ?? '');
    notifyListeners();
    return _user!;
  }

  Future<void> signOut() async {
    _token = null;
    _user = null;
    _expiresAt = null;
    _api.authToken = null;

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
    await prefs.remove(_expiryKey);

    notifyListeners();
  }
}
