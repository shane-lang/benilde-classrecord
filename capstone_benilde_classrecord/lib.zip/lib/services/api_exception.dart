/// A failure the user should see a message about.
///
/// [ApiException] means the server answered and said no — wrong password,
/// duplicate e-mail, invalid form. [NetworkException] means the server was
/// never reached at all, which is a different problem with a different fix.
class ApiException implements Exception {
  final String message;
  final int statusCode;

  /// Field-level messages from the server, keyed by field name.
  final Map<String, List<String>>? fieldErrors;

  ApiException(this.message, this.statusCode, {this.fieldErrors});

  bool get isUnauthorized => statusCode == 401;

  @override
  String toString() => message;
}

class NetworkException implements Exception {
  final String message;

  NetworkException([
    this.message =
        'Couldn’t reach the server. Check that the API is running and try again.',
  ]);

  @override
  String toString() => message;
}
