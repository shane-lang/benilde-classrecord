import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';
import 'api_exception.dart';

/// One place where every call to the .NET API goes through, so the token
/// header, the JSON encoding and the error handling are written once.
class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Set after signing in; cleared on sign-out.
  String? authToken;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        if (authToken != null) 'Authorization': 'Bearer $authToken',
      };

  Future<Map<String, dynamic>> get(String path) async {
    return _send(() => _client.get(ApiConfig.endpoint(path), headers: _headers));
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async {
    return _send(() => _client.post(
          ApiConfig.endpoint(path),
          headers: _headers,
          body: jsonEncode(body),
        ));
  }

  Future<Map<String, dynamic>> _send(Future<http.Response> Function() request) async {
    late http.Response response;
    try {
      response = await request().timeout(ApiConfig.timeout);
    } catch (_) {
      // Socket errors, DNS failures, timeouts — the server was never reached.
      throw NetworkException();
    }

    Map<String, dynamic> body = {};
    if (response.body.isNotEmpty) {
      try {
        final decoded = jsonDecode(response.body);
        if (decoded is Map<String, dynamic>) body = decoded;
      } catch (_) {
        // A non-JSON body (an HTML error page, say) leaves body empty and the
        // status code below decides the message.
      }
    }

    if (response.statusCode >= 200 && response.statusCode < 300) return body;

    throw ApiException(
      body['message'] as String? ?? _messageForStatus(response.statusCode),
      response.statusCode,
      fieldErrors: _parseFieldErrors(body['errors']),
    );
  }

  Map<String, List<String>>? _parseFieldErrors(Object? raw) {
    if (raw is! Map) return null;
    final result = <String, List<String>>{};
    raw.forEach((key, value) {
      if (value is List) {
        result['$key'] = value.map((e) => '$e').toList();
      }
    });
    return result.isEmpty ? null : result;
  }

  String _messageForStatus(int code) => switch (code) {
        400 => 'Please check the form and try again.',
        401 => 'Incorrect e-mail or password.',
        403 => 'This account isn’t allowed to do that.',
        404 => 'That wasn’t found on the server.',
        >= 500 => 'The server ran into a problem. Try again in a moment.',
        _ => 'Something went wrong. Try again.',
      };

  void close() => _client.close();
}
