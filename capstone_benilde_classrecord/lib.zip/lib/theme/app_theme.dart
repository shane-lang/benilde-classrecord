import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Centralized design system for Benilde ClassRecord.
///
/// Palette is themed around St. Benilde Center for Global Competence Inc.
/// (Olongapo) brand colors: deep green, black, and gold. Keeping every
/// color, radius and text style in one place means every screen
/// automatically looks consistent, and the whole app's look can be
/// re-tuned later by editing just this file.
class AppColors {
  AppColors._();

  // Brand — St. Benilde green
  static const Color primary = Color(0xFF0E6B3A); // Benilde deep green
  static const Color primaryDark = Color(0xFF0A4F2B); // darker green (pressed/emphasis)
  static const Color primaryLight = Color(0xFFE4F3E9); // pale green tint (chips/highlights)

  // Brand — gold accent (secondary brand color)
  static const Color gold = Color(0xFFC9A227);
  static const Color goldDark = Color(0xFFA3821B);
  static const Color goldLight = Color(0xFFFBF3DD);

  // Brand — black (used sparingly for strong contrast accents)
  static const Color brandBlack = Color(0xFF14201A);

  // Accents used for status / categories
  static const Color success = Color(0xFF16A34A); // green-600
  static const Color successBg = Color(0xFFF0FDF4); // green-50
  static const Color warning = Color(0xFFB8860B); // warm gold-brown, ties to gold accent
  static const Color warningBg = Color(0xFFFFF8E6);
  static const Color danger = Color(0xFFDC2626); // red-600
  static const Color dangerBg = Color(0xFFFEF2F2); // red-50
  static const Color info = Color(0xFF0F6B3A); // reuse brand green for info to stay on-brand
  static const Color infoBg = Color(0xFFE4F3E9);

  // Neutrals
  static const Color background = Color(0xFFF6F8F6); // faint green-tinted off-white
  static const Color surface = Color(0xFFFFFFFF);
  static const Color border = Color(0xFFE1E6E2); // soft green-gray
  static const Color textPrimary = Color(0xFF14201A); // near-black, brand-aligned
  static const Color textSecondary = Color(0xFF54615A);
  static const Color textMuted = Color(0xFF8A968F);
}

class AppRadius {
  AppRadius._();
  static const double sm = 10;
  static const double md = 14;
  static const double lg = 18;
  static const double pill = 999;
}

class AppTheme {
  AppTheme._();

  static ThemeData get light {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: Brightness.light,
      primary: AppColors.primary,
      secondary: AppColors.gold,
      error: AppColors.danger,
      surface: AppColors.surface,
    );

    const textColor = AppColors.textPrimary;

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.background,
      splashFactory: InkRipple.splashFactory,
      // "Comfortable" density = slightly taller/wider tap targets across
      // every default widget (buttons, list tiles, checkboxes, etc.) —
      // makes the app noticeably easier to use for teachers, especially
      // on smaller phone screens or for less tech-savvy users.
      visualDensity: VisualDensity.comfortable,

      // ---- Typography ----
      // Plus Jakarta Sans para sa headings (mas may "character" at modern
      // SaaS feel), Inter para sa body text (mas madaling basahin sa
      // maliliit na sizes gaya ng list subtitles at table cells).
      // Base sizes bumped up slightly across the board for readability.
      fontFamily: GoogleFonts.inter().fontFamily,
      textTheme: TextTheme(
        headlineMedium: GoogleFonts.plusJakartaSans(
          fontSize: 27,
          fontWeight: FontWeight.w700,
          color: textColor,
          letterSpacing: -0.5,
          height: 1.2,
        ),
        headlineSmall: GoogleFonts.plusJakartaSans(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: textColor,
          letterSpacing: -0.3,
        ),
        titleLarge: GoogleFonts.plusJakartaSans(
          fontSize: 19,
          fontWeight: FontWeight.w700,
          color: textColor,
        ),
        titleMedium: GoogleFonts.plusJakartaSans(
          fontSize: 17,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
        titleSmall: GoogleFonts.inter(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
        bodyLarge: GoogleFonts.inter(fontSize: 17, color: textColor, height: 1.45),
        bodyMedium: GoogleFonts.inter(
          fontSize: 15,
          color: AppColors.textSecondary,
          height: 1.45,
        ),
        bodySmall: GoogleFonts.inter(fontSize: 13, color: AppColors.textMuted),
        labelLarge: GoogleFonts.inter(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.1,
        ),
      ),

      // ---- AppBar ----
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.surface,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        scrolledUnderElevation: 1,
        surfaceTintColor: AppColors.surface,
        centerTitle: false,
        titleTextStyle: GoogleFonts.plusJakartaSans(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
          letterSpacing: -0.2,
        ),
        iconTheme: const IconThemeData(color: AppColors.textPrimary, size: 24),
        actionsIconTheme: const IconThemeData(color: AppColors.textSecondary, size: 24),
      ),

      // ---- Cards ----
      // Slightly more visible border + a whisper of elevation so cards read
      // clearly as separate tappable zones (helps at-a-glance scanning).
      cardTheme: CardThemeData(
        elevation: 0,
        color: AppColors.surface,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          side: const BorderSide(color: AppColors.border, width: 1.2),
        ),
      ),

      // ---- Buttons ----
      // Bigger minimum height (48dp+) so buttons are easy to tap accurately;
      // bolder label text so the primary action is always obvious.
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          disabledBackgroundColor: AppColors.primary.withValues(alpha: 0.4),
          elevation: 0,
          minimumSize: const Size.fromHeight(52),
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 22),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.primary,
          side: const BorderSide(color: AppColors.primary, width: 1.4),
          minimumSize: const Size.fromHeight(52),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.primary,
          minimumSize: const Size(64, 48),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          foregroundColor: AppColors.textSecondary,
          minimumSize: const Size(48, 48),
        ),
      ),

      // ---- Inputs ----
      // Switched from a filled/muddy background to a clean white field with
      // a clearly visible border, plus a thicker focus ring — makes it much
      // easier to tell which field is active while filling out forms
      // (attendance, grades, class setup, etc.).
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface,
        contentPadding: const EdgeInsets.symmetric(
          vertical: 16,
          horizontal: 16,
        ),
        labelStyle: const TextStyle(color: AppColors.textSecondary),
        hintStyle: const TextStyle(color: AppColors.textMuted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: const BorderSide(color: AppColors.border, width: 1.3),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: const BorderSide(color: AppColors.border, width: 1.3),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: const BorderSide(color: AppColors.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: const BorderSide(color: AppColors.danger, width: 1.3),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: const BorderSide(color: AppColors.danger, width: 2),
        ),
      ),

      // ---- FAB ----
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 2,
        extendedTextStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
      ),

      // ---- Misc ----
      dividerTheme: const DividerThemeData(
        color: AppColors.border,
        thickness: 1,
        space: 1,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.background,
        selectedColor: AppColors.primaryLight,
        labelStyle: const TextStyle(
          color: AppColors.textPrimary,
          fontWeight: FontWeight.w500,
          fontSize: 13.5,
        ),
        side: const BorderSide(color: AppColors.border),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.pill),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
      listTileTheme: const ListTileThemeData(
        iconColor: AppColors.textSecondary,
        minVerticalPadding: 12,
        titleTextStyle: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        subtitleTextStyle: TextStyle(
          fontSize: 13.5,
          color: AppColors.textSecondary,
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
        ),
        titleTextStyle: GoogleFonts.plusJakartaSans(
          fontSize: 19,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.brandBlack,
        contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14.5),
        // "fixed" instead of "floating": laging naka-dock ito sa ibaba ng
        // screen sa buong lapad, kaya hindi ito nagiging "off-screen" o
        // naka-clip sa napakaliit/maikling viewport (hal. maliit na window,
        // split-screen, o naka-emulate na maliit na device).
        behavior: SnackBarBehavior.fixed,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.primary,
      ),
      checkboxTheme: CheckboxThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(4),
        ),
        side: const BorderSide(color: AppColors.textSecondary, width: 1.5),
      ),
      tabBarTheme: const TabBarThemeData(
        labelColor: AppColors.primary,
        unselectedLabelColor: AppColors.textSecondary,
        indicatorColor: AppColors.primary,
        labelStyle: TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5),
      ),
    );
  }
}

/// Small reusable pill badge used across screens for status labels
/// (e.g. Present/Absent, Passed/Failed).
class StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final Color background;
  final IconData? icon;

  const StatusBadge({
    super.key,
    required this.label,
    required this.color,
    required this.background,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w700,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }
}