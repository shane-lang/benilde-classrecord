import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/class_model.dart';
import '../theme/app_theme.dart';
import '../widgets/ui_kit.dart';

/// ---------------------------------------------------------------------------
/// Create-class flow.
///
/// Wide screens get a two-pane layout: the form on the left, a live preview of
/// the resulting class card plus setup tips on the right. Narrow screens get
/// the same form in a single column. Both share one sticky action bar so the
/// primary action never scrolls out of reach.
/// ---------------------------------------------------------------------------
class AddClassScreen extends StatefulWidget {
  const AddClassScreen({super.key});

  @override
  State<AddClassScreen> createState() => _AddClassScreenState();
}

class _AddClassScreenState extends State<AddClassScreen> {
  static const double _wideBreakpoint = 980;

  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _subjectCodeController = TextEditingController();
  final _courseController = TextEditingController();
  final _yearSectionController = TextEditingController();

  // Common values at this school — one tap instead of typing.
  static const List<String> _courseSuggestions = [
    'BSIT',
    'BSCS',
    'BSBA',
    'BSED',
    'BSHM',
  ];
  static const List<String> _sectionSuggestions = ['1A', '1B', '2A', '3A', '4A'];

  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    for (final c in [
      _subjectController,
      _subjectCodeController,
      _courseController,
      _yearSectionController,
    ]) {
      c.addListener(_onFieldChanged);
    }
  }

  @override
  void dispose() {
    _subjectController.dispose();
    _subjectCodeController.dispose();
    _courseController.dispose();
    _yearSectionController.dispose();
    super.dispose();
  }

  void _onFieldChanged() {
    final hasText = _subjectController.text.isNotEmpty ||
        _subjectCodeController.text.isNotEmpty ||
        _courseController.text.isNotEmpty ||
        _yearSectionController.text.isNotEmpty;
    // setState on every keystroke keeps the live preview in sync.
    setState(() => _dirty = hasText);
  }

  bool get _isComplete =>
      _subjectController.text.trim().isNotEmpty &&
      _subjectCodeController.text.trim().isNotEmpty &&
      _courseController.text.trim().isNotEmpty &&
      _yearSectionController.text.trim().isNotEmpty;

  Future<void> _save() async {
    // Validation errors are shown inline; a toast explains why nothing saved.
    if (!_formKey.currentState!.validate()) {
      AppToast.show(
        context,
        'Please complete the highlighted fields.',
        type: ToastType.error,
      );
      return;
    }

    setState(() => _saving = true);
    // Short delay so the button's loading state is visible; this is also
    // where the .NET API call will go.
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (!mounted) return;

    final newClass = ClassModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      subjectName: _subjectController.text.trim(),
      subjectCode: _subjectCodeController.text.trim(),
      course: _courseController.text.trim(),
      yearSection: _yearSectionController.text.trim(),
    );

    Navigator.of(context).pop(newClass);
  }

  Future<void> _confirmDiscard() async {
    if (!_dirty) {
      Navigator.of(context).pop();
      return;
    }
    final discard = await showConfirmDialog(
      context,
      title: 'Discard this class?',
      message: 'The details you entered will not be saved.',
      confirmLabel: 'Discard',
      cancelLabel: 'Keep editing',
      destructive: true,
      icon: Icons.warning_amber_rounded,
    );
    if (discard && mounted) Navigator.of(context).pop();
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _confirmDiscard();
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= _wideBreakpoint;

            return Column(
              children: [
                _Header(onBack: _confirmDiscard),
                Expanded(
                  child: SingleChildScrollView(
                    padding: EdgeInsets.fromLTRB(
                      isWide ? 32 : 18,
                      isWide ? 28 : 20,
                      isWide ? 32 : 18,
                      32,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1060),
                        child: isWide
                            ? Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(flex: 6, child: _buildForm()),
                                  const SizedBox(width: 24),
                                  Expanded(flex: 4, child: _buildSideRail()),
                                ],
                              )
                            : Column(
                                children: [
                                  _buildForm(),
                                  const SizedBox(height: 20),
                                  _buildSideRail(),
                                ],
                              ),
                      ),
                    ),
                  ),
                ),
                _ActionBar(
                  saving: _saving,
                  complete: _isComplete,
                  onCancel: _confirmDiscard,
                  onSave: _save,
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ form

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _SectionTitle(
                  step: '1',
                  title: 'Subject',
                  subtitle: 'What are you teaching?',
                ),
                const SizedBox(height: 20),
                _Field(
                  label: 'Subject name',
                  child: TextFormField(
                    controller: _subjectController,
                    autofocus: true,
                    textCapitalization: TextCapitalization.words,
                    textInputAction: TextInputAction.next,
                    maxLength: 60,
                    decoration: const InputDecoration(
                      hintText: 'e.g. Web Development',
                      prefixIcon: Icon(Icons.menu_book_outlined, size: 20),
                      counterText: '',
                    ),
                    validator: (value) {
                      final v = value?.trim() ?? '';
                      if (v.isEmpty) return 'Enter the subject name.';
                      if (v.length < 3) return 'Use at least 3 characters.';
                      return null;
                    },
                  ),
                ),
                const SizedBox(height: 18),
                _Field(
                  label: 'Subject code',
                  helper: 'Shown as the short label on the class card.',
                  child: TextFormField(
                    controller: _subjectCodeController,
                    textCapitalization: TextCapitalization.characters,
                    textInputAction: TextInputAction.next,
                    maxLength: 12,
                    inputFormatters: [UpperCaseFormatter()],
                    decoration: const InputDecoration(
                      hintText: 'e.g. ITWEBDV',
                      prefixIcon: Icon(Icons.tag_rounded, size: 20),
                      counterText: '',
                    ),
                    validator: (value) {
                      final v = value?.trim() ?? '';
                      if (v.isEmpty) return 'Enter the subject code.';
                      return null;
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _SectionTitle(
                  step: '2',
                  title: 'Class',
                  subtitle: 'Who is taking it?',
                ),
                const SizedBox(height: 20),
                _Field(
                  label: 'Course',
                  child: TextFormField(
                    controller: _courseController,
                    textCapitalization: TextCapitalization.characters,
                    textInputAction: TextInputAction.next,
                    maxLength: 20,
                    decoration: const InputDecoration(
                      hintText: 'e.g. BSIT',
                      prefixIcon: Icon(Icons.school_outlined, size: 20),
                      counterText: '',
                    ),
                    validator: (value) =>
                        (value?.trim().isEmpty ?? true) ? 'Enter the course.' : null,
                  ),
                ),
                const SizedBox(height: 10),
                _QuickPicks(
                  values: _courseSuggestions,
                  selected: _courseController.text.trim().toUpperCase(),
                  onPick: (value) => _courseController.text = value,
                ),
                const SizedBox(height: 18),
                _Field(
                  label: 'Year & section',
                  child: TextFormField(
                    controller: _yearSectionController,
                    textCapitalization: TextCapitalization.characters,
                    textInputAction: TextInputAction.done,
                    maxLength: 12,
                    onFieldSubmitted: (_) => _save(),
                    decoration: const InputDecoration(
                      hintText: 'e.g. 3A',
                      prefixIcon: Icon(Icons.groups_outlined, size: 20),
                      counterText: '',
                    ),
                    validator: (value) => (value?.trim().isEmpty ?? true)
                        ? 'Enter the year & section.'
                        : null,
                  ),
                ),
                const SizedBox(height: 10),
                _QuickPicks(
                  values: _sectionSuggestions,
                  selected: _yearSectionController.text.trim().toUpperCase(),
                  onPick: (value) => _yearSectionController.text = value,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------- side rail

  Widget _buildSideRail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _PreviewCard(
          subjectName: _subjectController.text.trim(),
          subjectCode: _subjectCodeController.text.trim(),
          course: _courseController.text.trim(),
          yearSection: _yearSectionController.text.trim(),
        ),
        const SizedBox(height: 18),
        _Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.goldLight,
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                    child: const Icon(
                      Icons.lightbulb_outline_rounded,
                      size: 18,
                      color: AppColors.goldDark,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    'What happens next',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const _NextStep(
                icon: Icons.person_add_alt_rounded,
                title: 'Add your students',
                body: 'Enroll names and student numbers inside the class.',
              ),
              const _NextStep(
                icon: Icons.calendar_month_rounded,
                title: 'Set the schedule',
                body: 'Meeting days and grading period dates.',
              ),
              const _NextStep(
                icon: Icons.grade_rounded,
                title: 'Configure grading',
                body: 'Adjust category weights to match your syllabus.',
                last: true,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Forces typed input to upper case without fighting the cursor position.
class UpperCaseFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    return TextEditingValue(
      text: newValue.text.toUpperCase(),
      selection: newValue.selection,
      composing: TextRange.empty,
    );
  }
}

/// ---------------------------------------------------------------------------
/// Header with back button + breadcrumb
/// ---------------------------------------------------------------------------
class _Header extends StatelessWidget {
  final VoidCallback onBack;

  const _Header({required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.surface,
        border: Border(
          bottom: BorderSide(color: AppColors.border, width: 1.2),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 10, 18, 10),
          child: Row(
            children: [
              IconButton(
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
                tooltip: 'Back to my classes',
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            'My classes',
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5),
                          child: Icon(
                            Icons.chevron_right_rounded,
                            size: 15,
                            color: AppColors.textMuted,
                          ),
                        ),
                        const Flexible(
                          child: Text(
                            'New class',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Create a class',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// Sticky action bar
/// ---------------------------------------------------------------------------
class _ActionBar extends StatelessWidget {
  final bool saving;
  final bool complete;
  final VoidCallback onCancel;
  final VoidCallback onSave;

  const _ActionBar({
    required this.saving,
    required this.complete,
    required this.onCancel,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: const Border(
          top: BorderSide(color: AppColors.border, width: 1.2),
        ),
        boxShadow: AppShadows.card,
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1060),
              child: Row(
                children: [
                  // Status hint — tells the user what is still missing.
                  Expanded(
                    child: Row(
                      children: [
                        Icon(
                          complete
                              ? Icons.check_circle_rounded
                              : Icons.info_outline_rounded,
                          size: 17,
                          color: complete
                              ? AppColors.success
                              : AppColors.textMuted,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            complete
                                ? 'Ready to save'
                                : 'All four fields are required',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: complete
                                  ? AppColors.success
                                  : AppColors.textMuted,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  TextButton(
                    onPressed: saving ? null : onCancel,
                    style: TextButton.styleFrom(
                      foregroundColor: AppColors.textSecondary,
                      minimumSize: const Size(0, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                    ),
                    child: const Text('Cancel'),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: saving ? null : onSave,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(148, 48),
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                    ),
                    child: AnimatedSwitcher(
                      duration: AppMotion.fast,
                      child: saving
                          ? const Row(
                              key: ValueKey('saving'),
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(width: 10),
                                Text('Saving…'),
                              ],
                            )
                          : const Row(
                              key: ValueKey('idle'),
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.check_rounded, size: 19),
                                SizedBox(width: 8),
                                Text('Save class'),
                              ],
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// ---------------------------------------------------------------------------
/// Form building blocks
/// ---------------------------------------------------------------------------
class _Card extends StatelessWidget {
  final Widget child;

  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.border, width: 1.2),
        boxShadow: AppShadows.card,
      ),
      child: child,
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String step;
  final String title;
  final String subtitle;

  const _SectionTitle({
    required this.step,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 30,
          height: 30,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Text(
            step,
            style: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.w800,
              fontSize: 13.5,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 2),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ],
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String? helper;
  final Widget child;

  const _Field({required this.label, required this.child, this.helper});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.titleSmall),
        if (helper != null) ...[
          const SizedBox(height: 3),
          Text(helper!, style: Theme.of(context).textTheme.bodySmall),
        ],
        const SizedBox(height: 8),
        child,
      ],
    );
  }
}

class _QuickPicks extends StatelessWidget {
  final List<String> values;
  final String selected;
  final ValueChanged<String> onPick;

  const _QuickPicks({
    required this.values,
    required this.selected,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final value in values)
          Hoverable(
            builder: (context, hovered) {
              final isSelected = selected == value;
              return Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(AppRadius.pill),
                child: InkWell(
                  onTap: () => onPick(value),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  child: AnimatedContainer(
                    duration: AppMotion.fast,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 9,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primaryLight
                          : hovered
                              ? AppColors.background
                              : AppColors.surface,
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.border,
                        width: isSelected ? 1.5 : 1.2,
                      ),
                    ),
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: isSelected
                            ? AppColors.primary
                            : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
      ],
    );
  }
}

/// ---------------------------------------------------------------------------
/// Live preview of the class card the user is about to create
/// ---------------------------------------------------------------------------
class _PreviewCard extends StatelessWidget {
  final String subjectName;
  final String subjectCode;
  final String course;
  final String yearSection;

  const _PreviewCard({
    required this.subjectName,
    required this.subjectCode,
    required this.course,
    required this.yearSection,
  });

  @override
  Widget build(BuildContext context) {
    final seed = subjectCode.isNotEmpty ? subjectCode : subjectName;
    final gradient = AccentPalette.gradientFor(seed);
    final initials = seed.isEmpty
        ? '—'
        : AccentPalette.initialsFor(subjectCode, subjectName);

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.border, width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.visibility_outlined,
                size: 16,
                color: AppColors.textMuted,
              ),
              const SizedBox(width: 7),
              Text(
                'PREVIEW',
                style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.3,
                  color: AppColors.textMuted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          AnimatedContainer(
            duration: AppMotion.base,
            curve: AppMotion.curve,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.border, width: 1.2),
              boxShadow: AppShadows.card,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AnimatedContainer(
                      duration: AppMotion.base,
                      width: 44,
                      height: 44,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: seed.isEmpty
                              ? [AppColors.border, AppColors.border]
                              : gradient,
                        ),
                        borderRadius: BorderRadius.circular(AppRadius.sm),
                      ),
                      child: Text(
                        initials,
                        style: TextStyle(
                          color: seed.isEmpty
                              ? AppColors.textMuted
                              : Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            subjectName.isEmpty ? 'Subject name' : subjectName,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                  color: subjectName.isEmpty
                                      ? AppColors.textMuted
                                      : AppColors.textPrimary,
                                ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            subjectCode.isEmpty ? 'SUBJECT CODE' : subjectCode,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.8,
                              color: subjectCode.isEmpty
                                  ? AppColors.textMuted
                                  : gradient.first,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Divider(color: AppColors.border.withValues(alpha: 0.9)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    StatusBadge(
                      label: course.isEmpty ? 'Course' : course,
                      color: AppColors.textSecondary,
                      background: AppColors.background,
                      icon: Icons.school_outlined,
                    ),
                    StatusBadge(
                      label: yearSection.isEmpty ? 'Section' : yearSection,
                      color: AppColors.textSecondary,
                      background: AppColors.background,
                      icon: Icons.layers_outlined,
                    ),
                    const StatusBadge(
                      label: '0 students',
                      color: AppColors.primary,
                      background: AppColors.primaryLight,
                      icon: Icons.groups_outlined,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'This is how the class will appear on your dashboard.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    ).animate().fadeIn(duration: 350.ms);
  }
}

class _NextStep extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final bool last;

  const _NextStep({
    required this.icon,
    required this.title,
    required this.body,
    this.last = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: last ? 0 : 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 2),
                Text(body, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}