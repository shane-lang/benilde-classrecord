import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/class_model.dart';
import '../models/student_model.dart';
import '../models/assessment_model.dart';
import '../models/score_record.dart';
import '../models/attendance_record.dart';
import '../models/grading_category_model.dart';
import '../theme/app_theme.dart';

class StudentDetailScreen extends StatelessWidget {
  final ClassModel classModel;
  final StudentModel student;

  const StudentDetailScreen({
    super.key,
    required this.classModel,
    required this.student,
  });

  ScoreRecord? _findScore(String assessmentId) {
    for (final s in classModel.scores) {
      if (s.studentId == student.id && s.assessmentId == assessmentId) {
        return s;
      }
    }
    return null;
  }

  double? _percentForCategory(GradingPeriod period, String categoryId) {
    final assessments = classModel.assessments
        .where((a) => a.gradingPeriod == period && a.categoryId == categoryId)
        .toList();

    if (assessments.isEmpty) return null;

    double totalScore = 0;
    double totalMax = 0;
    bool hasAnyScore = false;

    for (final a in assessments) {
      final record = _findScore(a.id);
      if (record != null) {
        totalScore += record.score;
        totalMax += a.maxScore;
        hasAnyScore = true;
      }
    }

    if (!hasAnyScore || totalMax == 0) return null;
    return (totalScore / totalMax) * 100;
  }

  double? _attendancePercent(GradingPeriod period) {
    final records = classModel.attendanceRecords
        .where((r) => r.studentId == student.id && r.gradingPeriod == period)
        .toList();

    if (records.isEmpty) return null;

    final attendedCount =
        records.where((r) => r.status != AttendanceStatus.absent).length;

    return (attendedCount / records.length) * 100;
  }

  List<GradingCategoryModel> _childrenOf(String parentId) {
    return classModel.gradingCategories
        .where((c) => c.parentId == parentId)
        .toList();
  }

  double? _percentForAnyCategory(
      GradingPeriod period, GradingCategoryModel category) {
    if (category.isAttendance) return _attendancePercent(period);

    final children = _childrenOf(category.id);
    if (children.isEmpty) return _percentForCategory(period, category.id);

    double totalWeight = 0;
    double weightedSum = 0;
    for (final child in children) {
      final percent = _percentForAnyCategory(period, child);
      if (percent != null) {
        totalWeight += child.weight;
        weightedSum += child.weight * percent;
      }
    }
    if (totalWeight == 0) return null;
    return weightedSum / totalWeight;
  }

  double? _periodGrade(GradingPeriod period) {
    double totalWeight = 0;
    double weightedSum = 0;

    final topLevelCategories =
        classModel.gradingCategories.where((c) => c.parentId == null);

    for (final category in topLevelCategories) {
      final percent = _percentForAnyCategory(period, category);
      if (percent != null) {
        totalWeight += category.weight;
        weightedSum += category.weight * percent;
      }
    }

    if (totalWeight == 0) return null;
    return weightedSum / totalWeight;
  }

  double? _finalGrade() {
    final grades = [
      _periodGrade(GradingPeriod.prelim),
      _periodGrade(GradingPeriod.midterm),
      _periodGrade(GradingPeriod.finals),
    ].whereType<double>().toList();

    if (grades.isEmpty) return null;
    final sum = grades.reduce((a, b) => a + b);
    return sum / grades.length;
  }

  List<AssessmentModel> _assessmentsFor(GradingPeriod period) {
    return classModel.assessments
        .where((a) => a.gradingPeriod == period)
        .toList();
  }

  GradingCategoryModel? _categoryById(String id) {
    for (final c in classModel.gradingCategories) {
      if (c.id == id) return c;
    }
    return null;
  }

  String _periodLabel(GradingPeriod period) {
    switch (period) {
      case GradingPeriod.prelim:
        return 'Prelim';
      case GradingPeriod.midterm:
        return 'Midterm';
      case GradingPeriod.finals:
        return 'Finals';
    }
  }

  String _fmtPercent(double? v) => v != null ? '${v.toStringAsFixed(1)}%' : '—';

  String _fmtScore(double score) {
    if (score == score.roundToDouble()) return score.toStringAsFixed(0);
    return score.toString();
  }

  // Line chart ng grade trend across Prelim/Midterm/Finals - mabilis makita
  // kung tumataas o bumababa ang performance ng estudyante.
  Widget _gradeTrendChart(BuildContext context) {
    final values = [
      _periodGrade(GradingPeriod.prelim),
      _periodGrade(GradingPeriod.midterm),
      _periodGrade(GradingPeriod.finals),
    ];
    if (!values.any((v) => v != null)) return const SizedBox.shrink();

    final spots = <FlSpot>[
      for (var i = 0; i < values.length; i++)
        if (values[i] != null) FlSpot(i.toDouble(), values[i]!),
    ];

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 20, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Grade Trend', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),
            SizedBox(
              height: 140,
              child: LineChart(
                LineChartData(
                  minY: 0,
                  maxY: 100,
                  gridData: FlGridData(
                    show: true,
                    horizontalInterval: 25,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (_) =>
                        const FlLine(color: AppColors.border, strokeWidth: 1),
                  ),
                  borderData: FlBorderData(show: false),
                  lineTouchData: LineTouchData(
                    touchTooltipData: LineTouchTooltipData(
                      getTooltipColor: (_) => AppColors.textPrimary,
                      getTooltipItems: (spots) => spots
                          .map((s) => LineTooltipItem(
                                '${s.y.toStringAsFixed(1)}%',
                                const TextStyle(
                                    color: Colors.white, fontSize: 12),
                              ))
                          .toList(),
                    ),
                  ),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 30,
                        interval: 25,
                        getTitlesWidget: (value, meta) => Text(
                          '${value.toInt()}',
                          style: const TextStyle(
                              fontSize: 10, color: AppColors.textMuted),
                        ),
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          const labels = ['Prelim', 'Midterm', 'Finals'];
                          final i = value.toInt();
                          if (i < 0 || i >= labels.length) {
                            return const SizedBox.shrink();
                          }
                          return Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(
                              labels[i],
                              style: const TextStyle(
                                fontSize: 10,
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: AppColors.primary,
                      barWidth: 3,
                      dotData: FlDotData(
                        show: true,
                        getDotPainter: (spot, percent, bar, index) =>
                            FlDotCirclePainter(
                          radius: 4,
                          color: AppColors.primary,
                          strokeWidth: 2,
                          strokeColor: Colors.white,
                        ),
                      ),
                      belowBarData: BarAreaData(
                        show: true,
                        color: AppColors.primary.withValues(alpha: 0.12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.08, end: 0);
  }

  Widget _periodCard(BuildContext context, GradingPeriod period) {
    final assessments = _assessmentsFor(period);
    final grade = _periodGrade(period);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _periodLabel(period),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  _fmtPercent(grade),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: grade == null
                        ? AppColors.textMuted
                        : grade >= 75
                            ? AppColors.success
                            : AppColors.danger,
                  ),
                ),
              ],
            ),
            const Divider(height: 20),
            // Dynamic na breakdown - base sa categories na ginawa ng teacher
            ...classModel.gradingCategories
                .where((c) => c.parentId == null)
                .expand((category) {
              final percent = _percentForAnyCategory(period, category);
              final children = _childrenOf(category.id);
              return [
                _breakdownRow(
                  '${category.name} (${(category.weight * 100).toStringAsFixed(0)}%)',
                  percent,
                  bold: children.isNotEmpty,
                ),
                ...children.map((child) {
                  final childPercent = _percentForAnyCategory(period, child);
                  return _breakdownRow(
                    '   ${child.name} (${(child.weight * 100).toStringAsFixed(0)}% ng ${category.name})',
                    childPercent,
                    indented: true,
                  );
                }),
              ];
            }),
            if (assessments.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text(
                'Mga Assessment',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
              ),
              const SizedBox(height: 4),
              ...assessments.map((a) {
                final record = _findScore(a.id);
                final categoryName = _categoryById(a.categoryId)?.name ?? '';
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${a.name} ($categoryName)',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                      Text(
                        record != null
                            ? '${_fmtScore(record.score)} / ${a.maxScore.toStringAsFixed(0)}'
                            : 'wala pang score',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color:
                              record == null ? AppColors.textMuted : AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ] else
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  'Wala pang assessment sa period na ito.',
                  style: TextStyle(fontSize: 12, color: AppColors.textMuted),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _breakdownRow(
    String label,
    double? percent, {
    bool bold = false,
    bool indented = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: indented ? 12 : 13,
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
                color: indented ? AppColors.textSecondary : AppColors.textPrimary,
              ),
            ),
          ),
          Text(
            _fmtPercent(percent),
            style: TextStyle(
              fontSize: indented ? 12 : 13,
              fontWeight: FontWeight.w600,
              color: percent == null ? AppColors.textMuted : AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final finalGrade = _finalGrade();

    return Scaffold(
      appBar: AppBar(
        title: Text(student.name),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 26,
                    backgroundColor: Colors.indigo,
                    child: Icon(Icons.person, color: Colors.white, size: 28),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          student.name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          student.studentNumber,
                          style: const TextStyle(color: AppColors.textSecondary),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${classModel.subjectName} • ${classModel.course} - ${classModel.yearSection}',
                          style: const TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text(
                        'Final Avg',
                        style: TextStyle(fontSize: 11, color: AppColors.textMuted),
                      ),
                      Text(
                        _fmtPercent(finalGrade),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: finalGrade == null
                              ? AppColors.textMuted
                              : finalGrade >= 75
                                  ? AppColors.success
                                  : AppColors.danger,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.08, end: 0),
          const SizedBox(height: 16),
          _gradeTrendChart(context),
          _periodCard(context, GradingPeriod.prelim),
          _periodCard(context, GradingPeriod.midterm),
          _periodCard(context, GradingPeriod.finals),
        ],
      ),
    );
  }
}