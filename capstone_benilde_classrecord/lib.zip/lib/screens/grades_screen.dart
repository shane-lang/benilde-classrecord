import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../models/assessment_model.dart';
import '../models/attendance_record.dart';
import '../models/class_model.dart';
import '../models/grading_category_model.dart';
import '../models/score_record.dart';
import '../models/student_model.dart';
import '../theme/app_theme.dart';
import '../widgets/ui_kit.dart';
import 'attendance_screen.dart';
import 'category_grade_sheet_screen.dart';
import 'grading_categories_screen.dart';
import 'student_detail_screen.dart';

// ============================================================================
// Gradebook
//
// Each grading category is its own "sheet" (like tabs in Excel). This page
// is the hub: pick a period, open a sheet to record scores, and see where
// the class stands, all on one scrollable page. No floating bars and no
// hidden summaries.
// ============================================================================

const double _tabletBreakpoint = 760;
const double _desktopBreakpoint = 1120;
const double _passing = 75;

String _periodLabel(GradingPeriod p) {
  switch (p) {
    case GradingPeriod.prelim:
      return 'Prelim';
    case GradingPeriod.midterm:
      return 'Midterm';
    case GradingPeriod.finals:
      return 'Finals';
  }
}

Color _gradeColor(double? v) =>
    v == null ? AppColors.textMuted : (v >= _passing ? AppColors.success : AppColors.danger);

String _pct(double? v, {int digits = 1}) => v == null ? '—' : '${v.toStringAsFixed(digits)}%';

String _initials(String name) {
  final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
  if (parts.isEmpty) return '?';
  if (parts.length == 1) return parts.first[0].toUpperCase();
  return (parts.first[0] + parts.last[0]).toUpperCase();
}

IconData _iconForCategory(GradingCategoryModel category) {
  final n = category.name.toLowerCase();
  if (category.isAttendance) return Icons.event_available_rounded;
  if (n.contains('quiz')) return Icons.quiz_outlined;
  if (n.contains('exam')) return Icons.fact_check_outlined;
  if (n.contains('project')) return Icons.folder_special_outlined;
  if (n.contains('performance') || n.contains('task')) return Icons.task_alt_rounded;
  if (n.contains('activit') || n.contains('seatwork')) return Icons.edit_note_rounded;
  if (n.contains('recit')) return Icons.record_voice_over_outlined;
  if (n.contains('assign')) return Icons.assignment_outlined;
  return Icons.grid_view_rounded;
}

enum _SortMode { name, highest, lowest }

// ============================================================================

class GradesScreen extends StatefulWidget {
  final ClassModel classModel;

  const GradesScreen({super.key, required this.classModel});

  @override
  State<GradesScreen> createState() => _GradesScreenState();
}

class _GradesScreenState extends State<GradesScreen> {
  GradingPeriod _period = GradingPeriod.prelim;
  bool _loading = true;
  String _query = '';
  _SortMode _sort = _SortMode.name;
  final TextEditingController _searchCtrl = TextEditingController();

  ClassModel get _class => widget.classModel;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 320), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------ grade math
  // (Same rules as before: leaf categories average their assessments,
  // parents take the weighted average of their children, attendance comes
  // from attendance records, and missing categories are renormalized away.)

  List<GradingCategoryModel> _childrenOf(String parentId) =>
      _class.gradingCategories.where((c) => c.parentId == parentId).toList();

  /// Leaf categories become sheets; attendance has its own screen.
  List<GradingCategoryModel> get _sheetCategories => _class.gradingCategories
      .where((c) => !c.isAttendance && _childrenOf(c.id).isEmpty)
      .toList();

  GradingCategoryModel? get _attendanceCategory {
    for (final c in _class.gradingCategories) {
      if (c.isAttendance) return c;
    }
    return null;
  }

  ScoreRecord? _findScore(String studentId, String assessmentId) {
    for (final s in _class.scores) {
      if (s.studentId == studentId && s.assessmentId == assessmentId) return s;
    }
    return null;
  }

  List<AssessmentModel> _itemsIn(String categoryId, GradingPeriod period) => _class.assessments
      .where((a) => a.gradingPeriod == period && a.categoryId == categoryId)
      .toList();

  double? _leafPercent(String studentId, GradingPeriod period, String categoryId) {
    final items = _itemsIn(categoryId, period);
    if (items.isEmpty) return null;
    double score = 0;
    double max = 0;
    var any = false;
    for (final a in items) {
      final r = _findScore(studentId, a.id);
      if (r != null) {
        score += r.score;
        max += a.maxScore;
        any = true;
      }
    }
    if (!any || max == 0) return null;
    return score / max * 100;
  }

  double? _attendancePercent(String studentId, GradingPeriod period) {
    final records = _class.attendanceRecords
        .where((r) => r.studentId == studentId && r.gradingPeriod == period)
        .toList();
    if (records.isEmpty) return null;
    final attended = records.where((r) => r.status != AttendanceStatus.absent).length;
    return attended / records.length * 100;
  }

  double? _categoryPercent(String studentId, GradingPeriod period, GradingCategoryModel c) {
    if (c.isAttendance) return _attendancePercent(studentId, period);
    final children = _childrenOf(c.id);
    if (children.isEmpty) return _leafPercent(studentId, period, c.id);
    double w = 0;
    double sum = 0;
    for (final child in children) {
      final p = _categoryPercent(studentId, period, child);
      if (p != null) {
        w += child.weight;
        sum += child.weight * p;
      }
    }
    return w == 0 ? null : sum / w;
  }

  double? _classCategoryAverage(GradingCategoryModel c) {
    double total = 0;
    var n = 0;
    for (final s in _class.students) {
      final p = _categoryPercent(s.id, _period, c);
      if (p != null) {
        total += p;
        n++;
      }
    }
    return n == 0 ? null : total / n;
  }

  double? _periodGrade(String studentId, GradingPeriod period) {
    double w = 0;
    double sum = 0;
    for (final c in _class.gradingCategories.where((c) => c.parentId == null)) {
      final p = _categoryPercent(studentId, period, c);
      if (p != null) {
        w += c.weight;
        sum += c.weight * p;
      }
    }
    return w == 0 ? null : sum / w;
  }

  double? _finalGrade(String studentId) {
    final grades = GradingPeriod.values
        .map((p) => _periodGrade(studentId, p))
        .whereType<double>()
        .toList();
    if (grades.isEmpty) return null;
    return grades.reduce((a, b) => a + b) / grades.length;
  }

  double get _topLevelWeightTotal => _class.gradingCategories
      .where((c) => c.parentId == null)
      .fold<double>(0, (s, c) => s + c.weight);

  // -------------------------------------------------------------- navigation

  Future<void> _openSheet(GradingCategoryModel c) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CategoryGradeSheetScreen(classModel: _class, category: c, period: _period),
    ));
    if (mounted) setState(() {});
  }

  Future<void> _openAttendance() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => AttendanceScreen(classModel: _class)),
    );
    if (mounted) setState(() {});
  }

  Future<void> _openCategories() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GradingCategoriesScreen(classModel: _class)),
    );
    if (mounted) setState(() {});
  }

  Future<void> _openStudent(StudentModel s) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => StudentDetailScreen(classModel: _class, student: s)),
    );
    if (mounted) setState(() {});
  }

  // =================================================================== build

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final tablet = width >= _tabletBreakpoint;
    final desktop = width >= _desktopBreakpoint;
    final hPad = desktop ? 32.0 : (tablet ? 24.0 : 16.0);

    Widget body;
    if (_class.students.isEmpty) {
      body = _EmptyState(
        icon: Icons.group_add_outlined,
        title: 'No students in this class yet',
        message: 'Add students from the class page, then come back to record grades.',
        actionLabel: 'Back to class',
        actionIcon: Icons.arrow_back_rounded,
        onAction: () => Navigator.of(context).maybePop(),
      );
    } else if (_sheetCategories.isEmpty && _attendanceCategory == null) {
      body = _EmptyState(
        icon: Icons.dashboard_customize_outlined,
        title: 'No grading categories yet',
        message: 'Create categories like Quizzes or Exams. Each one becomes its own gradebook sheet.',
        actionLabel: 'Set up categories',
        actionIcon: Icons.tune_rounded,
        onAction: _openCategories,
      );
    } else {
      body = CustomScrollView(
        slivers: [
          SliverPadding(
            padding: EdgeInsets.fromLTRB(hPad, tablet ? 20 : 14, hPad, 40),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _header(tablet),
                SizedBox(height: tablet ? 18 : 14),
                _loading ? _StatsSkeleton(compact: !tablet) : _stats(tablet),
                if (!_loading && (_topLevelWeightTotal - 1).abs() > 0.001) ...[
                  const SizedBox(height: 14),
                  _weightWarning(),
                ],
                const SizedBox(height: 28),
                _sectionTitle(
                  'Grading sheets',
                  'Open a sheet to add items and record scores for ${_periodLabel(_period)}.',
                  trailing: tablet
                      ? TextButton.icon(
                          onPressed: _openCategories,
                          icon: const Icon(Icons.tune_rounded, size: 18),
                          label: const Text('Manage categories'),
                        )
                      : null,
                ),
                const SizedBox(height: 14),
                _loading ? _SheetGridSkeleton(columns: _columns(width)) : _sheetGrid(width),
                const SizedBox(height: 32),
                KeyedSubtree(
                  key: ValueKey(_period),
                  child: _standing(desktop, tablet),
                ),
              ]),
            ),
          ),
        ],
      );
    }

    return Scaffold(
      appBar: _appBar(tablet),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1280),
          child: body,
        ),
      ),
    );
  }

  PreferredSizeWidget _appBar(bool tablet) {
    final subtitle = _class.subjectCode.isNotEmpty
        ? '${_class.subjectCode}  ${_class.subjectName}'
        : _class.subjectName;
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_rounded),
        tooltip: 'Back to class',
        onPressed: () => Navigator.of(context).maybePop(),
      ),
      titleSpacing: 4,
      shape: const Border(bottom: BorderSide(color: AppColors.border)),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Gradebook',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, letterSpacing: -0.2, height: 1.15),
          ),
          Text(
            subtitle,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w500,
              color: AppColors.textMuted,
              height: 1.3,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.event_available_outlined),
          tooltip: 'Attendance',
          onPressed: _openAttendance,
        ),
        IconButton(
          icon: const Icon(Icons.tune_rounded),
          tooltip: 'Grading categories',
          onPressed: _openCategories,
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  // ------------------------------------------------------------------ header

  Widget _header(bool tablet) {
    final tabs = _PeriodTabs(
      selected: _period,
      counts: {
        for (final p in GradingPeriod.values)
          p: _class.assessments.where((a) => a.gradingPeriod == p).length,
      },
      onChanged: (p) => setState(() => _period = p),
    );
    if (!tablet) return tabs;

    final code = _class.subjectCode.isNotEmpty ? _class.subjectCode : _class.subjectName;
    return Row(
      children: [
        Flexible(
          child: Hoverable(
            builder: (context, hovered) => GestureDetector(
              onTap: () => Navigator.of(context).maybePop(),
              child: Text(
                code,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: hovered ? AppColors.primary : AppColors.textMuted,
                  decoration: hovered ? TextDecoration.underline : TextDecoration.none,
                  decorationColor: AppColors.primary,
                ),
              ),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 6),
          child: Icon(Icons.chevron_right_rounded, size: 16, color: AppColors.textMuted),
        ),
        const Text(
          'Gradebook',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        ),
        const Spacer(),
        SizedBox(width: 360, child: tabs),
      ],
    );
  }

  // ------------------------------------------------------------------- stats

  Widget _stats(bool tablet) {
    final grades = _class.students
        .map((s) => _periodGrade(s.id, _period))
        .whereType<double>()
        .toList();
    final avg = grades.isEmpty ? null : grades.reduce((a, b) => a + b) / grades.length;
    final passing = grades.where((g) => g >= _passing).length;
    final atRisk = grades.length - passing;
    final items = _class.assessments.where((a) => a.gradingPeriod == _period).length;
    final period = _periodLabel(_period);

    final tiles = <Widget>[
      _StatTile(
        icon: Icons.insights_rounded,
        color: avg == null ? AppColors.textMuted : _gradeColor(avg),
        background: avg == null
            ? AppColors.background
            : (avg >= _passing ? AppColors.successBg : AppColors.dangerBg),
        label: '$period average',
        value: _pct(avg),
        caption: avg == null
            ? 'No scores recorded yet'
            : 'From ${grades.length} of ${_class.students.length} students',
        progress: avg == null ? null : avg / 100,
        compact: !tablet,
      ),
      _StatTile(
        icon: Icons.verified_outlined,
        color: AppColors.primary,
        background: AppColors.primaryLight,
        label: 'Passing',
        value: grades.isEmpty ? '—' : '$passing/${grades.length}',
        caption: 'At ${_passing.toStringAsFixed(0)}% or higher',
        compact: !tablet,
      ),
      _StatTile(
        icon: atRisk == 0 ? Icons.check_circle_outline_rounded : Icons.warning_amber_rounded,
        color: atRisk == 0 ? AppColors.success : AppColors.danger,
        background: atRisk == 0 ? AppColors.successBg : AppColors.dangerBg,
        label: 'Below ${_passing.toStringAsFixed(0)}%',
        value: grades.isEmpty ? '—' : '$atRisk',
        caption: grades.isEmpty
            ? 'Shows once scores are in'
            : (atRisk == 0 ? 'Everyone is passing' : 'Need attention this period'),
        compact: !tablet,
      ),
      _StatTile(
        icon: Icons.library_books_outlined,
        color: AppColors.goldDark,
        background: AppColors.goldLight,
        label: 'Items this period',
        value: '$items',
        caption: 'Across ${_sheetCategories.length} sheets',
        compact: !tablet,
      ),
    ];

    if (tablet) {
      return IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < tiles.length; i++) ...[
              if (i > 0) const SizedBox(width: 12),
              Expanded(child: tiles[i]),
            ],
          ],
        ),
      );
    }
    return SizedBox(
      height: 132,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tiles.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) => SizedBox(width: 176, child: tiles[i]),
      ),
    );
  }

  Widget _weightWarning() {
    final total = (_topLevelWeightTotal * 100).round();
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
      decoration: BoxDecoration(
        color: AppColors.warningBg,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: AppColors.warning.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.balance_rounded, size: 20, color: AppColors.warning),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Category weights add up to $total%, not 100%. Grades are scaled to '
              'the categories that have data, so adjust the weights for accurate results.',
              style: const TextStyle(fontSize: 13.5, color: AppColors.textPrimary, height: 1.4),
            ),
          ),
          const SizedBox(width: 12),
          OutlinedButton(
            onPressed: _openCategories,
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(0, 40),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              foregroundColor: AppColors.warning,
              side: const BorderSide(color: AppColors.warning),
            ),
            child: const Text('Fix weights'),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, String subtitle, {Widget? trailing}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 3),
              Text(subtitle, style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 14)),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    );
  }

  // ----------------------------------------------------------- sheet grid

  int _columns(double width) => width >= _desktopBreakpoint ? 3 : (width >= 640 ? 2 : 1);

  Widget _sheetGrid(double width) {
    final cards = <Widget>[
      for (final c in _sheetCategories) _sheetCard(c),
      if (_attendanceCategory != null) _attendanceCard(_attendanceCategory!),
    ];
    return _Grid(columns: _columns(width), children: cards)
        .animate(key: ValueKey(_period))
        .fadeIn(duration: 220.ms);
  }

  Widget _sheetCard(GradingCategoryModel c) {
    String? parent;
    if (c.parentId != null) {
      for (final p in _class.gradingCategories) {
        if (p.id == c.parentId) parent = p.name;
      }
    }
    final count = _itemsIn(c.id, _period).length;
    return _SheetCard(
      icon: _iconForCategory(c),
      accent: AppColors.primary,
      accentBg: AppColors.primaryLight,
      title: c.name,
      weightLabel: parent != null
          ? '${(c.weight * 100).toStringAsFixed(0)}% of $parent'
          : '${(c.weight * 100).toStringAsFixed(0)}% of grade',
      meta: count == 0 ? 'No items yet' : '$count item${count == 1 ? '' : 's'}',
      average: _classCategoryAverage(c),
      emptyHint: count == 0 ? 'Open to add the first item' : 'No scores recorded yet',
      onTap: () => _openSheet(c),
    );
  }

  Widget _attendanceCard(GradingCategoryModel c) {
    final days = <DateTime>{
      for (final r in _class.attendanceRecords)
        if (r.gradingPeriod == _period) DateTime(r.date.year, r.date.month, r.date.day),
    }.length;
    return _SheetCard(
      icon: Icons.event_available_rounded,
      accent: AppColors.goldDark,
      accentBg: AppColors.goldLight,
      title: c.name,
      weightLabel: '${(c.weight * 100).toStringAsFixed(0)}% of grade',
      meta: days == 0 ? 'Synced from Attendance' : '$days class day${days == 1 ? '' : 's'} recorded',
      average: _classCategoryAverage(c),
      emptyHint: 'Take attendance to fill this in',
      onTap: _openAttendance,
      badge: 'Auto',
    );
  }

  // ------------------------------------------------------- class standing

  Widget _standing(bool desktop, bool tablet) {
    final table = _standingTable(tablet);
    final chart = _CategoryAverages(
      period: _periodLabel(_period),
      rows: [
        for (final c in _sheetCategories) (c.name, _classCategoryAverage(c)),
        if (_attendanceCategory != null)
          (_attendanceCategory!.name, _classCategoryAverage(_attendanceCategory!)),
      ],
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _sectionTitle(
          'Class standing',
          'Grades for every period. Final average is the mean of the periods with data.',
        ),
        const SizedBox(height: 14),
        if (desktop)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(flex: 7, child: table),
              const SizedBox(width: 16),
              Expanded(flex: 3, child: chart),
            ],
          )
        else ...[
          table,
          const SizedBox(height: 16),
          chart,
        ],
      ],
    );
  }

  Widget _standingTable(bool tablet) {
    final q = _query.trim().toLowerCase();
    final rows = _class.students
        .where((s) =>
            q.isEmpty || s.name.toLowerCase().contains(q) || s.studentNumber.toLowerCase().contains(q))
        .map((s) => (
              student: s,
              periods: {for (final p in GradingPeriod.values) p: _periodGrade(s.id, p)},
              finalGrade: _finalGrade(s.id),
            ))
        .toList();

    switch (_sort) {
      case _SortMode.name:
        rows.sort((a, b) => a.student.name.toLowerCase().compareTo(b.student.name.toLowerCase()));
      case _SortMode.highest:
        rows.sort((a, b) => (b.finalGrade ?? -1).compareTo(a.finalGrade ?? -1));
      case _SortMode.lowest:
        rows.sort((a, b) => (a.finalGrade ?? 999).compareTo(b.finalGrade ?? 999));
    }

    final toolbar = Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Row(
        children: [
          Expanded(
            child: SizedBox(
              height: 42,
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _query = v),
                style: const TextStyle(fontSize: 14.5),
                decoration: InputDecoration(
                  hintText: 'Search students',
                  prefixIcon: const Icon(Icons.search_rounded, size: 20, color: AppColors.textMuted),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Clear search',
                          icon: const Icon(Icons.close_rounded, size: 18),
                          onPressed: () {
                            _searchCtrl.clear();
                            setState(() => _query = '');
                          },
                        ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          PopupMenuButton<_SortMode>(
            tooltip: 'Sort students',
            initialValue: _sort,
            position: PopupMenuPosition.under,
            onSelected: (m) => setState(() => _sort = m),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppRadius.md),
              side: const BorderSide(color: AppColors.border),
            ),
            itemBuilder: (_) => const [
              PopupMenuItem(value: _SortMode.name, child: Text('Name A to Z')),
              PopupMenuItem(value: _SortMode.highest, child: Text('Highest final average')),
              PopupMenuItem(value: _SortMode.lowest, child: Text('Lowest final average')),
            ],
            child: Container(
              height: 42,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.sm),
                border: Border.all(color: AppColors.border, width: 1.3),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.sort_rounded, size: 18, color: AppColors.textSecondary),
                  if (tablet) ...[
                    const SizedBox(width: 8),
                    Text(
                      switch (_sort) {
                        _SortMode.name => 'Name',
                        _SortMode.highest => 'Highest',
                        _SortMode.lowest => 'Lowest',
                      },
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );

    const nameMin = 200.0;
    const numW = 92.0;
    const finalW = 150.0;

    Widget headerCell(String text, double w, {bool active = false, TextAlign align = TextAlign.right}) =>
        SizedBox(
          width: w,
          child: Text(
            text,
            textAlign: align,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: active ? AppColors.primary : AppColors.textSecondary,
            ),
          ),
        );

    Widget tableBody(double available) {
      final nameW = (available - numW * 3 - finalW - 32).clamp(nameMin, 420.0);
      final total = nameW + numW * 3 + finalW + 32;
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: total < available ? available : total,
          child: Column(
            children: [
              Container(
                height: 42,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: const BoxDecoration(
                  color: Color(0xFFF8FAF9),
                  border: Border(
                    top: BorderSide(color: AppColors.border),
                    bottom: BorderSide(color: AppColors.border),
                  ),
                ),
                child: Row(
                  children: [
                    headerCell('Student', nameW, align: TextAlign.left),
                    for (final p in GradingPeriod.values)
                      headerCell(_periodLabel(p), numW, active: p == _period),
                    headerCell('Final average', finalW),
                  ],
                ),
              ),
              if (rows.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 36),
                  child: Text(
                    'No students match “${_query.trim()}”',
                    style: const TextStyle(color: AppColors.textMuted, fontSize: 14),
                  ),
                )
              else
                for (final r in rows)
                  _StandingRow(
                    name: r.student.name,
                    number: r.student.studentNumber,
                    nameWidth: nameW,
                    numWidth: numW,
                    finalWidth: finalW,
                    periods: [for (final p in GradingPeriod.values) r.periods[p]],
                    activeIndex: GradingPeriod.values.indexOf(_period),
                    finalGrade: r.finalGrade,
                    onTap: () => _openStudent(r.student),
                  ),
            ],
          ),
        ),
      );
    }

    return _Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          toolbar,
          LayoutBuilder(builder: (context, c) => tableBody(c.maxWidth)),
        ],
      ),
    );
  }
}

// ============================================================================
// Components
// ============================================================================

class _Panel extends StatelessWidget {
  final Widget child;

  const _Panel({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.border, width: 1.2),
        boxShadow: AppShadows.card,
      ),
      clipBehavior: Clip.antiAlias,
      child: child,
    );
  }
}

/// Simple responsive grid with equal-height rows.
class _Grid extends StatelessWidget {
  final int columns;
  final List<Widget> children;

  const _Grid({required this.columns, required this.children});

  @override
  Widget build(BuildContext context) {
    const gap = 14.0;
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i += columns) {
      final slice = children.sublist(i, (i + columns).clamp(0, children.length));
      rows.add(IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var j = 0; j < columns; j++) ...[
              if (j > 0) const SizedBox(width: gap),
              Expanded(child: j < slice.length ? slice[j] : const SizedBox.shrink()),
            ],
          ],
        ),
      ));
    }
    return Column(
      children: [
        for (var i = 0; i < rows.length; i++) ...[
          if (i > 0) const SizedBox(height: gap),
          rows[i],
        ],
      ],
    );
  }
}

class _SheetCard extends StatelessWidget {
  final IconData icon;
  final Color accent;
  final Color accentBg;
  final String title;
  final String weightLabel;
  final String meta;
  final double? average;
  final String emptyHint;
  final VoidCallback onTap;
  final String? badge;

  const _SheetCard({
    required this.icon,
    required this.accent,
    required this.accentBg,
    required this.title,
    required this.weightLabel,
    required this.meta,
    required this.average,
    required this.emptyHint,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    final avg = average;
    return Semantics(
      button: true,
      label: '$title sheet, $weightLabel, ${avg == null ? 'no average yet' : 'class average ${avg.toStringAsFixed(1)} percent'}',
      excludeSemantics: true,
      child: Hoverable(
        builder: (context, hovered) => AnimatedContainer(
          duration: AppMotion.base,
          curve: AppMotion.curve,
          transform: Matrix4.translationValues(0, hovered ? -2 : 0, 0),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(
              color: hovered ? accent.withValues(alpha: 0.45) : AppColors.border,
              width: 1.2,
            ),
            boxShadow: hovered ? AppShadows.lifted : AppShadows.card,
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: accentBg,
                            borderRadius: BorderRadius.circular(AppRadius.sm),
                          ),
                          child: Icon(icon, size: 21, color: accent),
                        ),
                        const Spacer(),
                        if (badge != null) ...[
                          Tooltip(
                            message: 'Calculated automatically from attendance records',
                            child: StatusBadge(
                              label: badge!,
                              color: AppColors.goldDark,
                              background: AppColors.goldLight,
                              icon: Icons.sync_rounded,
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        AnimatedSlide(
                          duration: AppMotion.fast,
                          offset: Offset(hovered ? 0.2 : 0, 0),
                          child: Icon(
                            Icons.arrow_forward_rounded,
                            size: 19,
                            color: hovered ? accent : AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$weightLabel, $meta',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13, color: AppColors.textMuted, height: 1.35),
                    ),
                    const SizedBox(height: 16),
                    const Spacer(),
                    if (avg == null)
                      Row(
                        children: [
                          const Icon(Icons.hourglass_empty_rounded, size: 15, color: AppColors.textMuted),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              emptyHint,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      )
                    else ...[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${avg.toStringAsFixed(1)}%',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.4,
                              color: _gradeColor(avg),
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Padding(
                            padding: EdgeInsets.only(bottom: 4),
                            child: Text(
                              'class average',
                              style: TextStyle(fontSize: 12.5, color: AppColors.textMuted),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _Bar(value: avg / 100, color: _gradeColor(avg)),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  final double value;
  final Color color;
  final double height;

  const _Bar({required this.value, required this.color, this.height = 6});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.pill),
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: value.clamp(0.0, 1.0)),
        duration: const Duration(milliseconds: 550),
        curve: AppMotion.curve,
        builder: (_, v, __) => LinearProgressIndicator(
          value: v,
          minHeight: height,
          color: color,
          backgroundColor: const Color(0xFFEDF1EE),
        ),
      ),
    );
  }
}

class _StandingRow extends StatelessWidget {
  final String name;
  final String number;
  final double nameWidth;
  final double numWidth;
  final double finalWidth;
  final List<double?> periods;
  final int activeIndex;
  final double? finalGrade;
  final VoidCallback onTap;

  const _StandingRow({
    required this.name,
    required this.number,
    required this.nameWidth,
    required this.numWidth,
    required this.finalWidth,
    required this.periods,
    required this.activeIndex,
    required this.finalGrade,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final f = finalGrade;
    final Widget remark = f == null
        ? const StatusBadge(label: 'No grades', color: AppColors.textMuted, background: AppColors.background)
        : (f >= _passing
            ? const StatusBadge(label: 'Passing', color: AppColors.success, background: AppColors.successBg)
            : const StatusBadge(label: 'At risk', color: AppColors.danger, background: AppColors.dangerBg));

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        hoverColor: AppColors.primaryLight.withValues(alpha: 0.45),
        child: Container(
          height: 60,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: Color(0xFFEDF1EE))),
          ),
          child: Row(
            children: [
              SizedBox(
                width: nameWidth,
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      alignment: Alignment.center,
                      decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                      child: Text(
                        _initials(name),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primaryDark,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          if (number.isNotEmpty)
                            Text(
                              number,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              for (var i = 0; i < periods.length; i++)
                SizedBox(
                  width: numWidth,
                  child: Text(
                    periods[i] == null ? '—' : periods[i]!.toStringAsFixed(1),
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: i == activeIndex ? FontWeight.w700 : FontWeight.w500,
                      color: periods[i] == null
                          ? AppColors.textMuted
                          : (i == activeIndex ? AppColors.textPrimary : AppColors.textSecondary),
                      fontFeatures: const [FontFeature.tabularFigures()],
                    ),
                  ),
                ),
              SizedBox(
                width: finalWidth,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    remark,
                    const SizedBox(width: 10),
                    SizedBox(
                      width: 42,
                      child: Text(
                        f == null ? '—' : f.toStringAsFixed(1),
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: _gradeColor(f),
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryAverages extends StatelessWidget {
  final String period;
  final List<(String, double?)> rows;

  const _CategoryAverages({required this.period, required this.rows});

  @override
  Widget build(BuildContext context) {
    return _Panel(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Category averages', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 2),
            Text('$period, whole class',
                style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
            const SizedBox(height: 16),
            for (final r in rows) ...[
              Row(
                children: [
                  Expanded(
                    child: Text(
                      r.$1,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  Text(
                    _pct(r.$2),
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: _gradeColor(r.$2),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              _Bar(value: (r.$2 ?? 0) / 100, color: _gradeColor(r.$2), height: 8),
              const SizedBox(height: 14),
            ],
            Row(
              children: [
                Container(width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text('${_passing.toStringAsFixed(0)}% and up',
                    style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                const SizedBox(width: 14),
                Container(width: 10, height: 10, decoration: const BoxDecoration(color: AppColors.danger, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text('Below ${_passing.toStringAsFixed(0)}%',
                    style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------- period tabs

class _PeriodTabs extends StatelessWidget {
  final GradingPeriod selected;
  final Map<GradingPeriod, int> counts;
  final ValueChanged<GradingPeriod> onChanged;

  const _PeriodTabs({required this.selected, required this.counts, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const periods = GradingPeriod.values;
    final index = periods.indexOf(selected);
    return Container(
      height: 46,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: AppColors.border, width: 1.2),
      ),
      child: LayoutBuilder(builder: (context, c) {
        final segW = c.maxWidth / periods.length;
        return Stack(
          children: [
            AnimatedPositioned(
              duration: AppMotion.base,
              curve: AppMotion.curve,
              left: segW * index,
              top: 0,
              bottom: 0,
              width: segW,
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.25),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              children: [
                for (final p in periods)
                  Expanded(
                    child: Semantics(
                      selected: p == selected,
                      button: true,
                      label: '${_periodLabel(p)}, ${counts[p] ?? 0} items',
                      excludeSemantics: true,
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () => onChanged(p),
                          borderRadius: BorderRadius.circular(AppRadius.sm),
                          hoverColor: p == selected
                              ? Colors.transparent
                              : AppColors.primaryLight.withValues(alpha: 0.6),
                          child: Center(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  _periodLabel(p),
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: p == selected ? Colors.white : AppColors.textSecondary,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                  decoration: BoxDecoration(
                                    color: p == selected
                                        ? Colors.white.withValues(alpha: 0.2)
                                        : AppColors.background,
                                    borderRadius: BorderRadius.circular(AppRadius.pill),
                                  ),
                                  child: Text(
                                    '${counts[p] ?? 0}',
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w700,
                                      color: p == selected ? Colors.white : AppColors.textMuted,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        );
      }),
    );
  }
}

// ---------------------------------------------------------------- stat tile

class _StatTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Color background;
  final String label;
  final String value;
  final String caption;
  final double? progress;
  final bool compact;

  const _StatTile({
    required this.icon,
    required this.color,
    required this.background,
    required this.label,
    required this.value,
    required this.caption,
    this.progress,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: AppColors.border, width: 1.2),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(8)),
                child: Icon(icon, size: 16, color: color),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontSize: 24,
                  height: 1.1,
                  color: progress != null ? color : AppColors.textPrimary,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
          ),
          if (progress != null) ...[
            const SizedBox(height: 8),
            _Bar(value: progress!, color: color, height: 4),
          ],
          const SizedBox(height: 6),
          Text(
            caption,
            maxLines: compact ? 1 : 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12.5, color: AppColors.textMuted, height: 1.35),
          ),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------- empty / loading

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String actionLabel;
  final IconData actionIcon;
  final VoidCallback onAction;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.message,
    required this.actionLabel,
    required this.actionIcon,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                ),
                child: Icon(icon, size: 30, color: AppColors.primary),
              ),
              const SizedBox(height: 18),
              Text(title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 6),
              Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: onAction,
                icon: Icon(actionIcon, size: 18),
                label: Text(actionLabel),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(0, 46),
                  padding: const EdgeInsets.symmetric(horizontal: 22),
                ),
              ),
            ],
          ),
        ),
      ),
    ).animate().fadeIn(duration: 240.ms);
  }
}

class _StatsSkeleton extends StatelessWidget {
  final bool compact;

  const _StatsSkeleton({required this.compact});

  @override
  Widget build(BuildContext context) {
    Widget tile() => Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: AppColors.border, width: 1.2),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              SkeletonBox(width: 110, height: 14),
              SizedBox(height: 14),
              SkeletonBox(width: 64, height: 22),
              SizedBox(height: 10),
              SkeletonBox(width: 120, height: 11),
            ],
          ),
        );
    if (compact) {
      return SizedBox(
        height: 132,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 3,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, __) => SizedBox(width: 176, child: tile()),
        ),
      );
    }
    return Row(
      children: [
        for (var i = 0; i < 4; i++) ...[
          if (i > 0) const SizedBox(width: 12),
          Expanded(child: tile()),
        ],
      ],
    );
  }
}

class _SheetGridSkeleton extends StatelessWidget {
  final int columns;

  const _SheetGridSkeleton({required this.columns});

  @override
  Widget build(BuildContext context) {
    Widget card() => Container(
          height: 178,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: AppColors.border, width: 1.2),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SkeletonBox(width: 40, height: 40, radius: 10),
              SizedBox(height: 16),
              SkeletonBox(width: 140, height: 15),
              SizedBox(height: 8),
              SkeletonBox(width: 180, height: 12),
              Spacer(),
              SkeletonBox(height: 6, radius: 6),
            ],
          ),
        );
    return _Grid(columns: columns, children: [for (var i = 0; i < columns * 2; i++) card()]);
  }
}
