/// The signed-in teacher, as returned by the API.
class AuthUser {
  final int id;
  final String email;
  final String fullName;
  final String? department;

  const AuthUser({
    required this.id,
    required this.email,
    required this.fullName,
    this.department,
  });

  factory AuthUser.fromJson(Map<String, dynamic> json) => AuthUser(
        id: (json['id'] as num?)?.toInt() ?? 0,
        email: json['email'] as String? ?? '',
        fullName: json['fullName'] as String? ?? '',
        department: json['department'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'fullName': fullName,
        'department': department,
      };

  /// First name only, for greetings in the app bar.
  String get firstName {
    final parts = fullName.trim().split(RegExp(r'\s+'));
    return parts.isEmpty || parts.first.isEmpty ? 'Teacher' : parts.first;
  }
}
