class StudentModel {
  final String id;
  final String name;
  final String studentNumber;

  StudentModel({
    required this.id,
    required this.name,
    required this.studentNumber,
  });
}