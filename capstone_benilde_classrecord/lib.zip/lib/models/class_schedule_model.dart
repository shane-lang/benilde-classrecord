import 'assessment_model.dart';

// Ang start/end date ng isang grading period (hal. Prelim: Jan 5 - Feb 20).
// Ito ang magiging basehan kung anong mga petsa ang kasama sa "Prelim" vs
// "Midterm" vs "Finals" - kaya hiwalay talaga sila kahit magkasunod ang
// schedule ng klase (Lunes/Miyerkules, atbp.) sa buong school year.
class PeriodDateRange {
  DateTime start;
  DateTime end;

  PeriodDateRange({required this.start, required this.end});
}

// Ang buong schedule ng isang klase: anong araw ng linggo ito nagmi-meet,
// anong oras, at saan nagsisimula/natatapos bawat grading period. Base dito,
// awtomatikong ma-ge-generate ang listahan ng class days (walang manual
// pag-type ng bawat petsa) hanggang sa dulo ng grading period / school year.
class ClassScheduleModel {
  // 1 = Lunes ... 7 = Linggo (tugma sa DateTime.weekday)
  Set<int> meetingWeekdays;
  int startHour;
  int startMinute;
  int durationMinutes;
  Map<GradingPeriod, PeriodDateRange> periodRanges;

  // Mga petsang naka-mark na "walang pasok" (holiday/suspension) - hindi na
  // isasama sa auto-generated na class dates kahit tugma sa meeting weekday.
  Set<DateTime> holidayDates;

  // Maikling dahilan bakit walang pasok, hal. "Typhoon", "Holiday" - key ay
  // normalized (year/month/day lang) na petsa.
  Map<DateTime, String> holidayReasons;

  ClassScheduleModel({
    Set<int>? meetingWeekdays,
    this.startHour = 8,
    this.startMinute = 0,
    this.durationMinutes = 90,
    Map<GradingPeriod, PeriodDateRange>? periodRanges,
    Set<DateTime>? holidayDates,
    Map<DateTime, String>? holidayReasons,
  })  : meetingWeekdays = meetingWeekdays ?? <int>{},
        periodRanges = periodRanges ?? <GradingPeriod, PeriodDateRange>{},
        holidayDates = holidayDates ?? <DateTime>{},
        holidayReasons = holidayReasons ?? <DateTime, String>{};

  static DateTime normalize(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  bool isHoliday(DateTime date) => holidayDates.contains(normalize(date));

  void setHoliday(DateTime date, bool isHoliday, {String? reason}) {
    final normalized = normalize(date);
    if (isHoliday) {
      holidayDates.add(normalized);
      if (reason != null && reason.trim().isNotEmpty) {
        holidayReasons[normalized] = reason.trim();
      }
    } else {
      holidayDates.remove(normalized);
      holidayReasons.remove(normalized);
    }
  }

  static const List<String> weekdayShortNames = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  String get timeLabel {
    final period = startHour >= 12 ? 'PM' : 'AM';
    final hour12 = startHour % 12 == 0 ? 12 : startHour % 12;
    final minuteStr = startMinute.toString().padLeft(2, '0');
    return '$hour12:$minuteStr $period';
  }

  String get meetingDaysLabel {
    if (meetingWeekdays.isEmpty) return 'Wala pang naka-set';
    final sorted = meetingWeekdays.toList()..sort();
    return sorted.map((d) => weekdayShortNames[d - 1]).join(', ');
  }

  bool get isConfigured =>
      meetingWeekdays.isNotEmpty && periodRanges.length == GradingPeriod.values.length;

  // Lahat ng class dates sa isang grading period, base sa meeting days at sa
  // start/end date na naka-set ng teacher para dito. Ito ang "tuloy-tuloy"
  // na listahan hanggang matapos ang period (o school year, kung Finals).
  List<DateTime> classDatesFor(GradingPeriod period) {
    final range = periodRanges[period];
    if (range == null || meetingWeekdays.isEmpty) return [];

    final dates = <DateTime>[];
    var d = DateTime(range.start.year, range.start.month, range.start.day);
    final end = DateTime(range.end.year, range.end.month, range.end.day);

    while (!d.isAfter(end)) {
      if (meetingWeekdays.contains(d.weekday) && !isHoliday(d)) dates.add(d);
      d = d.add(const Duration(days: 1));
    }
    return dates;
  }

  // Alin ang grading period ng isang partikular na petsa, base sa mga
  // naka-set na date range (null kung wala/labas sa lahat ng range).
  GradingPeriod? periodForDate(DateTime date) {
    final normalized = DateTime(date.year, date.month, date.day);
    for (final entry in periodRanges.entries) {
      final start =
          DateTime(entry.value.start.year, entry.value.start.month, entry.value.start.day);
      final end =
          DateTime(entry.value.end.year, entry.value.end.month, entry.value.end.day);
      if (!normalized.isBefore(start) && !normalized.isAfter(end)) {
        return entry.key;
      }
    }
    return null;
  }
}