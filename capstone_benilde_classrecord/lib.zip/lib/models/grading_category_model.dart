class GradingCategoryModel {
  final String id;
  String name; // hal. "Quiz", "Exam", "Attendance", "Assessments"
  double weight; // 0.0 - 1.0

  // Kung meron itong parentId, ibig sabihin ito ay SUBCATEGORY: ang weight
  // nito ay porsyento ng share ng PARENT (dapat umabot ng 100% ang lahat ng
  // magkakapatid na subcategory). Kung null ang parentId, ito ay top-level
  // category, at ang weight nito ay porsyento ng BUONG grade (dapat umabot
  // ng 100% ang lahat ng top-level categories).
  String? parentId;

  // Attendance ay built-in na category - awtomatikong kinukuha ang % mula sa
  // AttendanceRecord sa halip na sa mga naka-score na assessment. Hindi ito
  // puwedeng burahin, pero puwedeng palitan ang pangalan/weight. Palaging
  // top-level (walang parent, walang anak).
  final bool isAttendance;

  GradingCategoryModel({
    required this.id,
    required this.name,
    required this.weight,
    this.parentId,
    this.isAttendance = false,
  });
}