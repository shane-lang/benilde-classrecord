enum GradingPeriod { prelim, midterm, finals }

class AssessmentModel {
  final String id;
  final String name; // e.g. "Quiz 1", "Midterm Exam"
  final String categoryId; // tumutukoy sa GradingCategoryModel.id
  final GradingPeriod gradingPeriod;
  final double maxScore;

  AssessmentModel({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.gradingPeriod,
    required this.maxScore,
  });

  String get periodLabel {
    switch (gradingPeriod) {
      case GradingPeriod.prelim:
        return 'Prelim';
      case GradingPeriod.midterm:
        return 'Midterm';
      case GradingPeriod.finals:
        return 'Finals';
    }
  }
}