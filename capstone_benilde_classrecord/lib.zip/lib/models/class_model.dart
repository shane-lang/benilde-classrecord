import 'student_model.dart';
import 'attendance_record.dart';
import 'assessment_model.dart';
import 'score_record.dart';
import 'grading_category_model.dart';
import 'class_schedule_model.dart';

class ClassModel {
  final String id;
  final String subjectName;
  final String subjectCode;
  final String course;
  final String yearSection;
  final List<StudentModel> students;
  final List<AttendanceRecord> attendanceRecords;
  final List<AssessmentModel> assessments;
  final List<ScoreRecord> scores;
  final List<GradingCategoryModel> gradingCategories;

  // Schedule ng klase (araw/oras ng meeting + start-end date bawat grading
  // period). Null hanggang hindi pa na-se-setup ng teacher sa Class
  // Schedule screen.
  ClassScheduleModel? schedule;

  ClassModel({
    required this.id,
    required this.subjectName,
    this.subjectCode = '',
    required this.course,
    required this.yearSection,
    List<StudentModel>? students,
    List<AttendanceRecord>? attendanceRecords,
    List<AssessmentModel>? assessments,
    List<ScoreRecord>? scores,
    List<GradingCategoryModel>? gradingCategories,
    this.schedule,
  })  : students = students ?? [],
        attendanceRecords = attendanceRecords ?? [],
        assessments = assessments ?? [],
        scores = scores ?? [],
        gradingCategories = gradingCategories ??
            [
              // Default na categories - tumutugma sa karaniwang breakdown na
              // makikita sa syllabus. Puwede itong baguhin, palitan ang
              // pangalan/weight, magdagdag/magbura ng bago, o i-group sa
              // ilalim ng isang parent category (hal. gawing subcategory ng
              // "Assessments") sa Grading Categories screen. Attendance lang
              // ang hindi puwedeng burahin.
              GradingCategoryModel(
                id: 'attendance',
                name: 'Attendance',
                weight: 0.05,
                isAttendance: true,
              ),
              GradingCategoryModel(id: 'quizzes', name: 'Quizzes', weight: 0.20),
              GradingCategoryModel(
                id: 'activities',
                name: 'Activities/Seatwork',
                weight: 0.15,
              ),
              GradingCategoryModel(
                id: 'performance_task',
                name: 'Performance Task',
                weight: 0.15,
              ),
              GradingCategoryModel(id: 'project', name: 'Project', weight: 0.10),
              GradingCategoryModel(
                id: 'major_exam',
                name: 'Major Exam (Midterm/Final)',
                weight: 0.35,
              ),
            ];
}