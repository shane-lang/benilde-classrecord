import 'assessment_model.dart';

enum AttendanceStatus { present, absent, late, excused }

class AttendanceRecord {
  final String studentId;
  final DateTime date;
  final AttendanceStatus status;
  final GradingPeriod gradingPeriod;
  final String? remarks;

  AttendanceRecord({
    required this.studentId,
    required this.date,
    required this.status,
    required this.gradingPeriod,
    this.remarks,
  });

  bool isSameDate(DateTime other) {
    return date.year == other.year &&
        date.month == other.month &&
        date.day == other.day;
  }
}