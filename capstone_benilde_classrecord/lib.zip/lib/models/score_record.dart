class ScoreRecord {
  final String studentId;
  final String assessmentId;
  double score;

  ScoreRecord({
    required this.studentId,
    required this.assessmentId,
    required this.score,
  });
}