import 'package:flutter/material.dart';

import 'screens/dashboard_screen.dart';
import 'screens/login_screen.dart';
import 'services/auth_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  // Needed before touching SharedPreferences from main().
  WidgetsFlutterBinding.ensureInitialized();

  // "Keep me signed in" is honoured here: if a saved token is still good, the
  // app opens straight on the dashboard instead of the sign-in screen.
  final signedIn = await AuthService.instance.restoreSession();

  runApp(ClassRecordApp(startSignedIn: signedIn));
}

class ClassRecordApp extends StatelessWidget {
  final bool startSignedIn;

  const ClassRecordApp({super.key, this.startSignedIn = false});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Benilde ClassRecord',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: startSignedIn ? '/dashboard' : '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/dashboard': (context) => const DashboardScreen(),
      },
    );
  }
}
