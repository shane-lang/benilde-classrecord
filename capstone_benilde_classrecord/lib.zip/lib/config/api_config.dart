import 'package:flutter/foundation.dart';

/// Where the .NET API lives.
///
/// The right host depends on where the app is running, because "localhost"
/// means something different on each one:
///   - Chrome / Windows desktop  → localhost reaches your own PC
///   - Android emulator          → 10.0.2.2 is the PC hosting the emulator
///   - iOS simulator             → localhost reaches the Mac
///   - A real phone on Wi-Fi     → your PC's LAN address, e.g. 192.168.1.10
class ApiConfig {
  ApiConfig._();

  /// The port from Properties/launchSettings.json in the API project.
  static const int port = 5214;

  /// Set this to your PC's LAN IP when testing on a real phone. Find it with
  /// `ipconfig` on Windows, under IPv4 Address.
  static const String lanHost = '192.168.1.10';

  static String get baseUrl {
    if (kIsWeb) return 'http://localhost:$port';

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        // An Android emulator cannot see the PC as "localhost".
        return 'http://10.0.2.2:$port';
      case TargetPlatform.iOS:
        return 'http://localhost:$port';
      case TargetPlatform.windows:
      case TargetPlatform.linux:
      case TargetPlatform.macOS:
        return 'http://localhost:$port';
      default:
        return 'http://$lanHost:$port';
    }
  }

  static Uri endpoint(String path) => Uri.parse('$baseUrl/api/$path');

  /// How long to wait before deciding the server is unreachable.
  static const Duration timeout = Duration(seconds: 15);
}
